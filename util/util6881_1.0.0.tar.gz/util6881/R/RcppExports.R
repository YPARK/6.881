read.plink <- function(bed.header) {

    glue <- function(...) paste(..., sep='')
    fam.file <- glue(bed.header, '.fam')
    bim.file <- glue(bed.header, '.bim')
    bed.file <- glue(bed.header, '.bed')
    stopifnot(file.exists(fam.file))
    stopifnot(file.exists(bim.file))
    stopifnot(file.exists(bed.file))

    ## 1. read .fam and .bim file
    fam <- read.table(fam.file)
    bim <- read.table(bim.file)
    n <- dim(fam)[1]
    n.snp <- dim(bim)[1]

    ## 2. read .bed
    bed <- .Call('read_plink_bed', PACKAGE = 'util6881', bed.file, n, n.snp)

    return(list(FAM=fam, BIM=bim, BED=bed))
}
